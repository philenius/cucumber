/*
  version.h - Version defines.
*/

#define PVERS	L"1.53"         // wide string
#define PVERSA	 "1.53"         // ANSI string (windres 2.16.91 didn't like L)
#define PVERE	L"153"          // wide environment string
#define PVEREA	 "153"          // ANSI environment string
#define PVERB	1,5,3,0 	// binary (resource)
